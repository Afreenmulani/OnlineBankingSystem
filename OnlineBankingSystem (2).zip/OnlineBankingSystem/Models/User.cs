using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBankingSystem.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [RegularExpression(@"^[A-Za-z\s]+$", ErrorMessage = "Name can only contain letters and spaces.")]

        public string? Name { get; set; }

        [Required(ErrorMessage = "Please enter your email Id")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string? Email { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be 10 digits. Please enter valid Phone number")]
        public string? MobileNumber { get; set; }

        [RegularExpression(@"^\d{12}$", ErrorMessage = "Aadhar number must be exactly 12 digits.")]
        public string? AadharNumber { get; set; }


        [Required(ErrorMessage = "Date of Birth is required.")]
        [DataType(DataType.Date)]
        [Range(typeof(DateTime), "1900-01-01", "2020-12-31", ErrorMessage = "Date of Birth must be between 01/01/1900 and 31/12/2020.")]
        public DateTime DateOfBirth { get; set; }
        public string? ResidentialAddress { get; set; }
        public string? PermanentAddress { get; set; }
        public string? Occupation { get; set; }
        public string Status { get; set; } = "Pending"; // Default Status

        public Account? Account { get; set; }
    }

}