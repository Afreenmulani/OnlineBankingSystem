using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.Identity.Client;

namespace OnlineBankingSystem.Models
{
    public class Registration
    {
        [Key]
        public int RegistrationId { get; set; }

        public int AccountId { get; set; }

        public Account? Account { get; set; }

        [Required(ErrorMessage = "Account number is required.")]
        public string? AccountNo { get; set; }

        [Required(ErrorMessage = "Login password is required.")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Login password must be between 6 and 20 characters.")]
        [DataType(DataType.Password)]
        public string? LoginPassword { get; set; }

        [Required(ErrorMessage = "Transaction password is required.")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Transaction password must be between 6 and 20 characters.")]
        [DataType(DataType.Password)]
        public string? TransactionPassword { get; set; }
    }
}