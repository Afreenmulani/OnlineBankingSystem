using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.DTOs;
using OnlineBankingSystem.Repositories;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Concurrent;
using OnlineBankingSystem.Services;
using OnlineBankingSystem.Data;
using Microsoft.EntityFrameworkCore;


namespace OnlineBanking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginRepository _loginRepository;
        private readonly EmailService _emailService;

        private readonly BankContext _context;

        private static Dictionary<string, string> _otpStore = new Dictionary<string, string>(); // Temporary OTP storage

        private static HashSet<string> _otpVerifiedForPasswordReset = new();


        public LoginController(ILoginRepository loginRepository, EmailService emailService, BankContext context)
        {
            _loginRepository = loginRepository;
            _emailService = emailService;
            _context = context;
        }


        private string GenerateJwtToken(int userId)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("fFjH8*5oI3j@1tJ9Pz4sQwL2zD6kVzBd+Ur1uFjG9Km43XfXk+0WBk5KrS2zYt9E"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim(ClaimTypes.Role,"User")
    };

            var token = new JwtSecurityToken(
                issuer: "OnlineBankingSystem",
                audience: "OnlineBankingClients",
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static ConcurrentDictionary<int, (int FailedAttempts, bool IsLocked)> _loginAttempts =
                    new ConcurrentDictionary<int, (int FailedAttempts, bool IsLocked)>();

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO loginDTO)
        {
            if (loginDTO == null || loginDTO.UserId == null || string.IsNullOrEmpty(loginDTO.LoginPassword))
            {
                return BadRequest("UserId and Password are required.");
            }

            int userId = loginDTO.UserId.Value;

            // Check if the account is locked or not
            if (_loginAttempts.TryGetValue(userId, out var loginStatus) && loginStatus.IsLocked)
            {
                return Unauthorized("Account is locked due to multiple failed login attempts. Please reset your password.");
            }


            var isValid = await _loginRepository.ValidateLoginAsync(userId, loginDTO.LoginPassword);
            if (!isValid)
            {
                var currentAttempts = _loginAttempts.GetOrAdd(userId, (0, false)).FailedAttempts + 1;


                if (currentAttempts >= 3)
                {
                    _loginAttempts[userId] = (currentAttempts, true);
                    return Unauthorized("Account is locked after 3 failed login attempts. Please reset your password.");
                }


                _loginAttempts[userId] = (currentAttempts, false);
                return Unauthorized("Invalid UserId or Password.");
            }


            _loginAttempts[userId] = (0, false);


            var token = GenerateJwtToken(userId);

            return Ok(new
            {
                Message = "Login successful.",
                Token = token
            });
        }


        [HttpPost("forget-user-id")]
        public async Task<IActionResult> ForgetUserId([FromBody] ForgetUserIdDTO request)
        {

            var account = _context.Accounts.FirstOrDefault(a => a.AccountNo == request.AccountNo);
            if (account == null)
                return BadRequest("Invalid account number.");


            var user = _context.Users.FirstOrDefault(u => u.UserId == account.UserId);
            if (user == null || string.IsNullOrEmpty(user.Email))
                return BadRequest("Email not registered for this account.");


            var otp = new Random().Next(100000, 999999).ToString();
            _otpStore[request.AccountNo] = otp;


            var subject = "Your OTP for Forget User ID";
            var body = $"Your OTP for verifying your account is: {otp}. It will expire in 5 minutes.";
            await _emailService.SendEmailAsync(user.Email, subject, body);

            return Ok("OTP sent to your registered email.");
        }

        [HttpPost("verify-otp")]
        public IActionResult VerifyOtp([FromBody] VerifyOtpDTO request)
        {

            if (!_otpStore.ContainsKey(request.AccountNo))
                return BadRequest("OTP not generated for this account number.");

            if (_otpStore[request.AccountNo] != request.OTP)
                return BadRequest("Invalid OTP.");


            var account = _context.Accounts.FirstOrDefault(a => a.AccountNo == request.AccountNo);
            if (account == null)
                return BadRequest("Invalid account number.");


            var userId = account.UserId;

            // Remove OTP after successful verification
            _otpStore.Remove(request.AccountNo);

            return Ok(new { UserId = userId });
        }


        [HttpPost("forget-password")]
        public async Task<IActionResult> ForgetPassword([FromBody] ForgetPasswordDTO forgetPasswordDTO)
        {
            if (forgetPasswordDTO == null || forgetPasswordDTO.UserId <= 0)
                return BadRequest("UserId is required.");

            var account = await _context.Accounts.FirstOrDefaultAsync(a => a.UserId == forgetPasswordDTO.UserId);
            if (account == null)
                return BadRequest("No account found for the provided UserId.");

            var registration = await _context.Registrations.FirstOrDefaultAsync(r => r.AccountId == account.AccountId);
            if (registration == null || string.IsNullOrEmpty(registration.LoginPassword))
                return BadRequest("Login information not found for this user.");

            var user = await _context.Users.FindAsync(forgetPasswordDTO.UserId);
            if (user == null || string.IsNullOrEmpty(user.Email))
                return BadRequest("User not found or email not registered.");

            var otp = new Random().Next(100000, 999999).ToString();


            _otpStore[forgetPasswordDTO.UserId.ToString()] = otp;

            var subject = "Password Reset OTP";
            var body = $"Your OTP for password reset is: {otp}. It is valid for 5 minutes.";
            await _emailService.SendEmailAsync(user.Email, subject, body);

            return Ok("OTP sent to the registered email.");
        }



        [HttpPost("verify-otp-for-password-reset")]
        public IActionResult VerifyOtpForPasswordReset([FromBody] VerifyOtpDTO verifyOtpDTO)
        {
            if (verifyOtpDTO == null || verifyOtpDTO.UserId <= 0 || string.IsNullOrEmpty(verifyOtpDTO.OTP))
                return BadRequest("UserId and OTP are required.");

            var userIdKey = verifyOtpDTO.UserId.ToString();

            if (_otpStore.ContainsKey(userIdKey) && _otpStore[userIdKey] == verifyOtpDTO.OTP)
            {

                _otpVerifiedForPasswordReset.Add(userIdKey);

                return Ok("OTP verified. You can now reset your password.");
            }

            return BadRequest("Invalid OTP.");
        }


        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDTO resetPasswordDTO)
        {
            if (resetPasswordDTO == null || resetPasswordDTO.UserId <= 0 ||
                string.IsNullOrEmpty(resetPasswordDTO.NewPassword) || string.IsNullOrEmpty(resetPasswordDTO.ConfirmPassword))
            {
                return BadRequest("All fields are required.");
            }

            if (resetPasswordDTO.NewPassword != resetPasswordDTO.ConfirmPassword)
                return BadRequest("Passwords do not match.");

            var userIdKey = resetPasswordDTO.UserId.ToString();

            // Ensure OTP was verified for this UserId
            if (!_otpVerifiedForPasswordReset.Contains(userIdKey))
                return BadRequest("OTP not verified. Please verify the OTP before resetting your password.");

            var registration = _context.Registrations.FirstOrDefault(r => r.Account.UserId == resetPasswordDTO.UserId);
            if (registration == null)
                return NotFound("User not found.");

            registration.LoginPassword = resetPasswordDTO.NewPassword;
            await _context.SaveChangesAsync();

            // Remove UserId from OTP verification tracker after successful reset
            _otpVerifiedForPasswordReset.Remove(userIdKey);

            return Ok("Password reset successfully.");
        }

    }
}
