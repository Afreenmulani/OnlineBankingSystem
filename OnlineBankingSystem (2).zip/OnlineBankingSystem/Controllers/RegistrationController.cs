using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.DTOs;
using OnlineBankingSystem.Repositories;
using System.Threading.Tasks;
using OnlineBankingSystem.Services;

namespace OnlineBanking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        private readonly IRegistrationRepository _registrationRepository;


        private static Dictionary<string, string> _otpStore = new();

        private readonly EmailService _emailService;



        public RegistrationController(IRegistrationRepository registrationRepository, EmailService emailService)
        {
            _registrationRepository = registrationRepository;
            _emailService = emailService;
        }



        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistrationDTO registrationDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (registrationDTO == null)
            {
                return BadRequest("Registration data is required.");
            }


            if (registrationDTO.LoginPassword != registrationDTO.ConfirmLoginPassword)
            {
                return BadRequest("Login passwords do not match.");
            }

            if (registrationDTO.TransactionPassword != registrationDTO.ConfirmTransactionPassword)
            {
                return BadRequest("Transaction passwords do not match.");
            }


            var account = await _registrationRepository.GetAccountByAccountNoAsync(registrationDTO.AccountNo);
            if (account == null)
            {
                return NotFound("Account number not found.");
            }

            // Get the email from the associated User entity
            var email = account.User?.Email;
            if (string.IsNullOrEmpty(email))
            {
                return NotFound("Email associated with this account not found.");
            }

            // Generate OTP
            var otp = new Random().Next(100000, 999999).ToString();

            // Store OTP temporarily 
            _otpStore[registrationDTO.AccountNo] = otp;


            var subject = "OTP for Registration";
            var body = $"Your OTP for registration is: {otp}. It is valid for 5 minutes.";
            await _emailService.SendEmailAsync(email, subject, body);

            return Ok("OTP sent to your registered email. Please verify the OTP to complete the registration.");
        }

        [HttpPost("verify-otp")]
        public async Task<IActionResult> VerifyOtp(string accountNo, string otp)
        {
            if (!_otpStore.ContainsKey(accountNo))
            {
                return BadRequest("OTP not generated for this account.");
            }

            if (_otpStore[accountNo] != otp)
            {
                return BadRequest("Invalid OTP.");
            }

            // OTP is valid; remove it from the temporary store
            _otpStore.Remove(accountNo);

            return Ok("OTP verified successfully. You can now complete the registration.");
        }


        [HttpPost("complete-registration")]
        public async Task<IActionResult> CompleteRegistration([FromBody] RegistrationDTO registrationDTO)
        {
            if (registrationDTO == null || string.IsNullOrEmpty(registrationDTO.AccountNo))
            {
                return BadRequest("Account number is required.");
            }


            var account = await _registrationRepository.GetAccountByAccountNoAsync(registrationDTO.AccountNo);
            if (account == null)
            {
                return NotFound("Account number not found.");
            }


            if (_otpStore.ContainsKey(registrationDTO.AccountNo))
            {
                return BadRequest("OTP not verified. Please verify the OTP first.");
            }


            var registration = new Registration
            {
                AccountNo = registrationDTO.AccountNo,
                LoginPassword = registrationDTO.LoginPassword,
                TransactionPassword = registrationDTO.TransactionPassword,
                AccountId = account.AccountId
            };


            var createdRegistration = await _registrationRepository.CreateRegistrationAsync(registration);

            return Ok(new
            {
                RegistrationId = createdRegistration.RegistrationId,
                AccountNo = createdRegistration.AccountNo,
                Message = "Registration successful for Internet Banking."
            });
        }
    }
}
