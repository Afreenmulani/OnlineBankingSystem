using Microsoft.AspNetCore.Mvc;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.DTOs;
using OnlineBankingSystem.Repositories;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IAccountRepository _accountRepository;

        public UserController(IUserRepository userRepository, IAccountRepository accountRepository)
        {
            _userRepository = userRepository;
            _accountRepository = accountRepository;
        }

        // POST api/user
        [HttpPost("create")]
        public async Task<IActionResult> CreateUser([FromBody] UserDTO userDto)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (userDto == null)
            {
                return BadRequest("Invalid user data.");
            }

            // Check if user already exists
            var existingUser = await _userRepository.GetByEmailAsync(userDto.Email);
            if (existingUser != null)
            {
                return Conflict("User with this email already exists.");
            }

            // Create a new User
            var user = new User
            {
                Name = userDto.Name,
                Email = userDto.Email,
                MobileNumber = userDto.MobileNumber,
                AadharNumber = userDto.AadharNumber,
                DateOfBirth = userDto.DateOfBirth,
                ResidentialAddress = userDto.ResidentialAddress,
                PermanentAddress = userDto.PermanentAddress,
                Occupation = userDto.Occupation,
                Status = "Pending"  // Set status as Pending
            };

            var createdUser = await _userRepository.CreateAsync(user);

            // Return the response indicating approval pending
            return CreatedAtAction(nameof(GetUser), new { id = createdUser.UserId }, new { Message = "Approval pending", User = createdUser });
        }

        // GET api/user/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            var account = await _accountRepository.GetByUserIdAsync(id);

            if (user.Status == "Pending")
            {
                return Ok(new { User = user, Message = "Approval Pending" });
            }

            return Ok(new { User = user, Account = account });
        }
    }
}
