using OnlineBankingSystem.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public interface IBeneficiaryRepository
    {
        Task<Beneficiary> AddBeneficiaryAsync(Beneficiary beneficiary);
        Task<IEnumerable<Beneficiary>> GetBeneficiariesAsync();
        Task<Beneficiary?> GetBeneficiaryByIdAsync(int beneficiaryId);
        Task<bool> BeneficiaryExistsAsync(string accountNo);
        Task<bool> AccountNumberExistsAsync(string accountNo);

    }
}
