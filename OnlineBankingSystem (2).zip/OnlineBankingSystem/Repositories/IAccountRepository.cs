using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public interface IAccountRepository
    {
        Task<Account> GetByUserIdAsync(int userId);
        Task<Account> CreateAsync(Account account);
    }
}
