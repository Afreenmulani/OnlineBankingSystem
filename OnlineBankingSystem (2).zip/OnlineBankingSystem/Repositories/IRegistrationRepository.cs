using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public interface IRegistrationRepository
    {

        Task<Registration> CreateRegistrationAsync(Registration registration);
        Task<Account> GetAccountByAccountNoAsync(string accountNo);

        Task<Registration> GetRegistrationByAccountNoAsync(string accountNo);


        Task<Registration> GetByLoginPasswordAsync(string loginPassword);


        Task<Registration> GetByTransactionPasswordAsync(string transactionPassword);


    }
}
