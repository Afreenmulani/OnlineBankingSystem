using Microsoft.EntityFrameworkCore;
using OnlineBankingSystem.Data;
using OnlineBankingSystem.Models;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly BankContext _context;

        public AdminRepository(BankContext context)
        {
            _context = context;
        }

        public async Task<Admin?> AuthenticateAdminAsync(string username, string password)
        {
            return await _context.Admins
                .FirstOrDefaultAsync(admin => admin.UserName == username && admin.Password == password);
        }

        public async Task<bool> ApproveUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null || user.Status == "Approved")
            {
                return false; // User not found or already approved
            }

            user.Status = "Approved";
            await _context.SaveChangesAsync();

            var account = new Account
            {
                UserId = user.UserId,
                AccountNo = GenerateAccountNumber(),
                AccountName = $"{user.Name}'s Account",
                AccountType = "Savings",
                Balance = 1000
            };

            _context.Accounts.Add(account);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> RejectUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null || user.Status == "Rejected" || user.Status == "Approved")
            {
                return false; // Cannot reject if already approved or rejected
            }

            user.Status = "Rejected";
            await _context.SaveChangesAsync();

            return true;
        }

        private string GenerateAccountNumber()
        {
            Random rand = new Random();
            return $"ACC{rand.Next(100000, 999999)}";
        }
    }
}
