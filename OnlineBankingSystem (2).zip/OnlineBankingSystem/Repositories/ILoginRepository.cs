using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{

    public interface ILoginRepository
    {
        Task<bool> ValidateLoginAsync(int userId, string loginPassword);

        Task<int?> GetUserIdByAccountNoAsync(string accountNo);

        Task<bool> UpdatePasswordAsync(int userId, string newPassword);

        Task<string> GetEmailByAccountNoAsync(string accountNo);

    }


}
