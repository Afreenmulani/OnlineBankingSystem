using Microsoft.EntityFrameworkCore;
using OnlineBankingSystem.Data;
using OnlineBankingSystem.Models;
using System.Threading.Tasks;

namespace OnlineBankingSystem.Repositories
{
    public class RegistrationRepository : IRegistrationRepository
    {
        private readonly BankContext _context;

        // Constructor to inject the DbContext for database operations
        public RegistrationRepository(BankContext context)
        {
            _context = context;
        }

        // Get an account record by account number
        public async Task<Account> GetAccountByAccountNoAsync(string accountNo)
        {
            var account = await _context.Accounts
                .Include(a => a.User) // Assuming Account has a related User entity
                .FirstOrDefaultAsync(a => a.AccountNo == accountNo);

            return account;
        }

        // Get a registration record by account number
        public async Task<Registration> GetRegistrationByAccountNoAsync(string accountNo)
        {
            return await _context.Registrations
                .FirstOrDefaultAsync(r => r.AccountNo == accountNo);
        }

        // Get a registration by login password
        public async Task<Registration> GetByLoginPasswordAsync(string loginPassword)
        {
            return await _context.Registrations
                .FirstOrDefaultAsync(r => r.LoginPassword == loginPassword);
        }

        // Get a registration by transaction password
        public async Task<Registration> GetByTransactionPasswordAsync(string transactionPassword)
        {
            return await _context.Registrations
                .FirstOrDefaultAsync(r => r.TransactionPassword == transactionPassword);
        }

        // Create and save a new registration record
        public async Task<Registration> CreateRegistrationAsync(Registration registration)
        {
            // Add the new registration record to the database
            _context.Registrations.Add(registration);
            await _context.SaveChangesAsync(); // Commit changes to the database

            return registration; // Return the created registration
        }
    }
}
