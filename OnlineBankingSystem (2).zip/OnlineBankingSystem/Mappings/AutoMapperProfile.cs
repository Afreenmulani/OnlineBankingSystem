using AutoMapper;
using OnlineBankingSystem.Models;
using OnlineBankingSystem.DTOs;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
        // Define mappings here
         CreateMap<User, UserDTO>().ReverseMap();
        CreateMap<Beneficiary, BeneficiaryDTO>().ReverseMap();
        CreateMap<Registration, RegistrationDTO>().ReverseMap();
        CreateMap<Transaction, TransactionDTO>().ReverseMap();
        CreateMap<Account, AccountDTO>().ReverseMap();
        CreateMap<Admin, AdminDTO>().ReverseMap();
        
        // Add any additional models and DTO mappings below as needed
    }
}
