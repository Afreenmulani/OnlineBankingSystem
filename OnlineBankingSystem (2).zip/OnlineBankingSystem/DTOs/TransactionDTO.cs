using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBankingSystem.DTOs
{
    public class TransactionDTO
{
    // public int TransactionId { get; set; }
    public string? FromAcc { get; set; }
    public string? ToAcc { get; set; }
    public decimal? Amount { get; set; }
    public string? TransactionType { get; set; }
    public DateTime Date { get; set; }
}

}