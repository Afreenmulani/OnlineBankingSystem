namespace OnlineBankingSystem.DTOs
{
    public class LoginDTO
    {
        public int? UserId { get; set; }
        public string? LoginPassword { get; set; }
    }
}
